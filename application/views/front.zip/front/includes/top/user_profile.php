		<link href="<?php echo base_url();?>template/front/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>template/back/plugins/switchery/switchery.min.css" rel="stylesheet">
